Name: Lucas MacQuarrie 
Student number: 20234554
Class: Numerical Analysis 

# Files 

These are the files in this zip. 

## myfirstprogram.cpp

This is my C++ submission for part 2 of assignment 1. This is my first C++ program so please let me know if you notice any poor coding practices or things I could improve on. 

The success of this program relies on your environment. You will need GNUplot for this to run. I also am not sure if popen works the same on all operating systems. This should work on Linux and Mac so long as GNUplot is installed. If this does not work on your system I have prepared .txt files and .png's in the folder 'exports' which contain the data points to be plotted and their resulting plots respectively for questions 1, 2, and 3.

## myfirstprogram

I think this is the binaries of the cpp program? I'm not sure if this is usable for you or if it is normal to build from source everytime, but I include it incase it is necessary. 

## exports 

The .pngs and .txt's as mentioned above

## Numerical_Analaysis_Homework_1.pdf

PDF for the written part of the assignment.

## HW1.ipynb

This includes the scrip in Julia used to simplify the lagrange polynomial in one of the written questions. 

## assgn_1.pdf

Assignment pdf. 


